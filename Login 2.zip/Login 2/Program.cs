﻿using System;
using System.Collections.Generic;

namespace Login_2
{
    class Program
    {
        static void Main()
        {
            bool ingelogd = false;
            int pogingen = 3;
            while (pogingen > 0 && pogingen <= 3)
            {
                for (int i = 0; i < 3; i++)
                {
                    Dictionary<string, string> goed = new Dictionary<string, string>()
            {
                {"1", "1"},
            };
                    Console.WriteLine("Gebruikersnaam");
                    string gebruikersnaam = Console.ReadLine();

                    string wachtwoord = "";
                    Console.WriteLine("Wachtwoord: ");
                    ConsoleKeyInfo info = Console.ReadKey(true);
                    while (info.Key != ConsoleKey.Enter)
                    {
                        if (info.Key != ConsoleKey.Backspace)
                        {
                            Console.Write("*");
                            wachtwoord += info.KeyChar;
                        }
                        else if (info.Key == ConsoleKey.Backspace && wachtwoord.Length > 0)
                        {
                            wachtwoord.Remove(wachtwoord.Length - 1);
                            Console.Write("\b \b");
                        }
                        info = Console.ReadKey(true);
                    }
                    if (info.Key == ConsoleKey.Enter)
                    {
                        if (goed.ContainsKey(gebruikersnaam) && goed[gebruikersnaam].Equals(wachtwoord))
                        {
                            ingelogd = true;
                            while (true)
                            {
                                Console.Clear();
                                Console.WriteLine("");
                                Console.WriteLine(" ~ U bent succesvol ingelogd.");
                                Console.WriteLine(" ~ maak uw keuze.");
                                Console.WriteLine("1 - Voorraad schoenen bekijken");
                                Console.WriteLine("2 - Schoenen Inkopen");
                                Console.WriteLine("3 - uitloggen");
                                int keuze = Convert.ToInt32(Console.ReadLine());

                                switch (keuze)
                                {
                                    case 1:
                                    {
                                        Console.Clear();
                                        Console.WriteLine(" 1 - Nike");
                                        Console.WriteLine(" 2 - Adidas");
                                        Console.WriteLine(" 3 - Puma");
                                        int schoenmerk = Convert.ToInt32(Console.ReadLine());
                                        switch (schoenmerk)
                                        {
                                                case 1:
                                                Console.Clear();
                                                Console.WriteLine("Nike");
                                                Console.WriteLine("Jordan");
                                                Console.WriteLine("41");
                                                Console.WriteLine("Grijs");
                                                Console.WriteLine("$309,99");
                                                Console.WriteLine("6 - terug");
                                                int back;
                                                back = int.Parse(Console.ReadLine());
                                                if (back == 6)
                                                {
                                                    break;
                                                }
                                                break;
                                                case 2:
                                                    Console.Clear();
                                                    Console.WriteLine("Adidas");
                                                    Console.WriteLine("Yeezy");
                                                    Console.WriteLine("42");
                                                    Console.WriteLine("Oranje");
                                                    Console.WriteLine("$449,99");
                                                    Console.WriteLine("6 - terug");
                                                    int terug;
                                                    terug = int.Parse(Console.ReadLine());
                                                    if (terug == 6)
                                                    {
                                                        break;
                                                    }
                                                    break;
                                                case 3:
                                                    Console.WriteLine("Puma");
                                                    Console.WriteLine("Boost");
                                                    Console.WriteLine("41");
                                                    Console.WriteLine("Wit");
                                                    Console.WriteLine("$49,99");
                                                    Console.WriteLine("6 - terug");
                                                    int vorige;
                                                    vorige = int.Parse(Console.ReadLine());
                                                    if (vorige == 6)
                                                    {
                                                        break;
                                                    }
                                                    break;
                                        }

                                        break;
                                    }

                                    case 2: 
                                        
                                        Console.Clear();
                                        Console.WriteLine("awdnbawjdnbawd");
                                            
                                            break;
                                        
                                        
                                }
                            }
                        }
                        {
                            pogingen--;
                            Console.WriteLine("");
                            Console.WriteLine("Onjuist Wachtwoord of Gebruikersnaam. ");
                            Console.Clear();
                            Console.WriteLine("Je hebt nog " + pogingen + " pogingen over \n");
                        }
                    }
                    if (pogingen == 0)
                    {
                        Console.WriteLine("U heeft te vaak geprobeerd in te loggen. ");
                        Console.Clear();
                        Console.WriteLine("");
                        Environment.Exit(0);
                    }
                }
            }
        }
    }
}